<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Purchase\\Providers\\PurchaseServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Purchase\\Providers\\PurchaseServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);