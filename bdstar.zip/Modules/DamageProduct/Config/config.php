<?php

return [
    'name' => 'DamageProduct'
];
